/**
 * 
 */
/**
 * @author ELCOT
 *
 */
module GasBookingApp {
	requires java.sql;
	requires java.logging;
}